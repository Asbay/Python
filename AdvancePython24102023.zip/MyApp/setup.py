from setuptools import setup

setup(name='mypackage',
      version='1.1',
      description='My package for testing',
      url="#",
      author="InstructorOmer",
      author_email='omer@email.com',
      license='deneme',
      packages=['mypackage'],
      zip_safe=False)