def SayHello(name):
    print(f"Hi {name}! How are you?")

__name__ = "SayHello"