from mypackage import power, average, SayHello

SayHello("Hello Python Developers")

x = power(3, 2)

print("power(3, 2): ", x)